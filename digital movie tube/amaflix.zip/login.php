<?php
session_start();

 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
  <title>amaFlix-Homepage</title>
  <link rel="stylesheet" href="master.css" type="text/css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  </head>
  <body style="background-image: url(images/6.jpeg);">
    <header>
      
      
        <nav class="navbar navbar-expand-md navbar-dark bg-dark" style='background-image: url(images/10.jpeg);' >
            <a href="login.php" class="navbar-brand"> <img src="images/lo.png" alt=""> </a>
            <span class="navbar-text" style="color:red;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;amaFlix&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>

            <ul class="navbar-nav" >
              <li class="nav-item"> <a href="#A" class="nav-link" style="color:yellow;background-color:darkred;font-size: 30px;font-weight: bold;border: 2px solid blue;"> Services</a> </li>
              <li class="nav-item"> <a href="user-login.php" class="nav-link" style="color:yellow;background-color:darkred;font-size: 30px;font-weight: bold;border: 2px solid blue;"> &nbsp;SignIn&nbsp;</a> </li>

            </ul>
        </nav>
        <div class="container-fluid" style="background-image:url(images/a.jpg);">

        <center><h1 style="color: black;font-style: italic;font-size: 40px;font-weight: bold;
        ">welcome to<br> <h1 style="color: ghostwhite;font-style: italic;font-size: 50px;font-weight: bold;
        ">amaFLIX </h1></h1></center>
   


        <div class="container">
          <div class="jumbotron" style="background-image: url(images/ba.jpeg);">
            <h1  style="background-color: yellow;color: black;font-style: italic;border: 3px solid white;">-----------unlimited entertainment-----------<br><h1 style="background-color: red;color: white;font-style:oblique;border: 3px solid hotpink;">Watch Anywhere, <br> Watch Anytime... </h1> <br>

            <a href="test.php" type="button" class="btn btn-danger btn-block" style="background-color:black;">Sign Up Now to enjoy..</a>
          </div>
        </div>
      </div>

      </header>



    <section class="features" >
        <a href="#" name="A"></a>
        <h2>Our Services</h2>

        <div class="container">
          <div class="row">
            <div class="col-md-4">
             <br><br><br><br><br><br><br><br><img src="images/mob.png" alt=""><p class="arrange" style="background-color: black;color:white;"> Smart Search <br> Content search on Disney+ Hotstar has been optimized to reduce complexity and delay in accessing content. Accurate search results, with lightning fast autocomplete suggestions navigate users to video with minimal navigation friction and ease of use.<br>

Friendly User Interface <br> Content organization on Disney+ Hotstar is a result of a thoughtful user experience approach and strong design principles that ensure that the user is not overwhelmed with the breadth of content available. Using a mix of algorithms and human curation, users at any stage of their interaction with Disney+ Hotstar will discover content and see their experience evolve with their interaction patterns over time.<br>






              </p>
            </div><div class="col-md-4">
              <p class="arrange"  style="color:white;"><img src="images/logos.png" style="height: 50px;width: 80px;"><h3 style="font-size: 50px;"><center>ABOUT US</center></h3> 
                 <p class="arrange"  style="color:white;background-color: black;">
amaFLIX is an online movie streaming platform owned by Novi Digital Entertainment Private Limited, a wholly owned subsidiary of Star India Private Limited. Disney+ Hotstar currently offers over 100,000 hours of TV content and movies across 9 languages, and every major sport covered live. Highly evolved video streaming technology and a high attention to quality of experience across devices and platforms, make Disney+ Hotstar the most complete video destination for Over The Top (OTT) video consumers.<br>

A Video Experience Like No Other<br>
Seamless Video Playback <br> Our adaptive video streaming technology ensures that the best possible video quality is played back automatically based on the available bandwidth, therefore making it a great video experience on both mobile networks as well as WiFi internet connections. Our video is optimized to play on mobile networks with inconsistent throughput so that our users don't have to compromise on their experience on the low end, and play HD quality video on the top end of bandwidth availability. Additionally, our users can manually select the quality of video that suits their taste.

              </p>
            </div>
              <div class="col-md-4">

                <p class="arrange"  style="color:white;">
                 <br><br><br><br><br> <img src="images/desk.jpg"><p class="arrange" style="background-color: black;color:white;">   Hot Content Catalogue <br> Disney+ Hotstar offers the latest and popular TV, movies and knowledge-based content from India and the world. With content in 8 languages, spanning 15 TV channels, Disney+ Hotstar is home to some of the longest running, and highest rated TV content in the country. Our roster of the biggest names in Indian cinema makes Disney+ Hotstar the preferred destination for the biggest blockbusters from Bollywood and regional cinema.<br>
                 Originals <br>In our endeavour to drive meaningful engagement with our audience, Disney+ Hotstar is investing in generating content keeping in mind the sentiments and attitudes of our consumers and has enjoyed great success with original programming content such as On Air with AIB, M Bole Toh, One Tip One Hand.
                </p>
              </div>

            </div>

          </div>
          <h3></h3>

    </section>
    <footer class="page-footer font-small blue">

      <div class="footer-copyright text-center py-3">any query:
        <a href="">contact us..</a>
      </div>

    </footer>
  </body>
</html>
